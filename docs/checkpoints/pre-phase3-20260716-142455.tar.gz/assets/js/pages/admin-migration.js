(function () {
  "use strict";

  /*
   * Migration Center interactions.
   *
   * The scope table, field mapping, and cutover plan are static in the
   * page so the screen is fully readable even if this script fails.
   * This controller only drives the optional "dry run" demonstration,
   * which deterministically re-validates the modeled ServiceNow export
   * and updates the readiness figures. No records are ever written.
   */

  const UI = window.MasterFlowUI || {};

  const TOTAL = 5012;
  const PASS = 4995;
  const WARN = 14;
  const BLOCKING = 3;

  const button = document.getElementById("runDryRun");
  const bar = document.getElementById("valBar");
  const valCount = document.getElementById("valCount");
  const valPass = document.getElementById("valPass");
  const valWarn = document.getElementById("valWarn");
  const valErr = document.getElementById("valErr");
  const kpiPass = document.getElementById("kpiPass");
  const kpiPassMeta = document.getElementById("kpiPassMeta");
  const kpiBlocking = document.getElementById("kpiBlocking");
  const subhead = document.getElementById("valSubhead");

  if (!button) return;

  const passRate = ((PASS / TOTAL) * 100).toFixed(1) + "%";

  function setText(node, value) {
    if (node) node.textContent = value;
  }

  // Show the completed state on first load so the screen never looks empty.
  if (bar) requestAnimationFrame(() => { bar.style.width = "100%"; });

  let running = false;

  function runDryRun() {
    if (running) return;
    running = true;
    button.disabled = true;
    button.textContent = "Validating…";
    setText(subhead, "Validating every record against its mapping. No records are written during a dry run.");

    if (bar) bar.style.width = "0%";
    setText(valCount, "0");
    setText(valPass, "0");
    setText(valWarn, "0");
    setText(valErr, "0");

    const durationMs = 1600;
    const start = performance.now();

    function tick(now) {
      const progress = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - progress, 3);
      if (bar) bar.style.width = Math.round(eased * 100) + "%";
      setText(valCount, Math.round(eased * TOTAL).toLocaleString());
      setText(valPass, Math.round(eased * PASS).toLocaleString());
      if (progress >= 0.6) setText(valWarn, String(WARN));
      if (progress >= 0.85) setText(valErr, String(BLOCKING));

      if (progress < 1) {
        requestAnimationFrame(tick);
      } else {
        setText(valCount, TOTAL.toLocaleString());
        setText(valPass, PASS.toLocaleString());
        setText(valWarn, String(WARN));
        setText(valErr, String(BLOCKING));
        setText(kpiPass, passRate);
        setText(kpiPassMeta, PASS.toLocaleString() + " of " + TOTAL.toLocaleString() + " records pass");
        setText(kpiBlocking, String(BLOCKING));
        setText(subhead, "Dry run complete. " + BLOCKING + " blocking issues must be resolved before cutover; warnings are safe to migrate.");
        button.disabled = false;
        button.textContent = "Re-run validation dry run";
        running = false;
        if (typeof UI.showToast === "function") {
          UI.showToast("Dry run complete: " + PASS.toLocaleString() + " passed, " + WARN + " warnings, " + BLOCKING + " blocking.");
        }
      }
    }

    requestAnimationFrame(tick);
  }

  button.addEventListener("click", runDryRun);
})();
