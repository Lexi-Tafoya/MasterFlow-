(function () {
  "use strict";

  const STORAGE_KEY = "masterflowMultipageStateV1";
  const ROLE_KEY = "masterflowDemoRole";
  const CURRENT_USER = {
    id: "usr-alexandra",
    name: "Alexandra Tafoya",
    initials: "AT",
    email: "alexandra.tafoya@example.invalid",
    department: "Packaging Operations",
    team: "Packaging - Phoenix",
    site: "Phoenix Distribution Center",
    workLocation: "Packaging area, Phoenix",
    manager: "Dana Whitfield",
    phone: "(602) 555-0114",
    extension: "4471"
  };

  function isoMinutesFromNow(minutes) {
    return new Date(Date.now() + minutes * 60 * 1000).toISOString();
  }

  function isoHoursFromNow(hours) {
    return isoMinutesFromNow(hours * 60);
  }

  function deepClone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function seedState() {
    const now = Date.now();
    return {
      version: 1,
      nextTicketSequence: 1854,
      currentUser: deepClone(CURRENT_USER),
      tickets: [
        {
          id: "t-1842",
          number: "ME-2026-1842",
          title: "Connect to printer",
          description: "Need help connecting workstation P-14 to printer PHX-PRN-22.",
          category: "Hardware / Printer",
          priority: "P3 - Normal",
          queue: "IT Support",
          requester: "Alexandra Tafoya",
          department: "Packaging Operations",
          assignee: "Jordan Kim",
          status: "Waiting on requester",
          createdAt: new Date(now - 2.2 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 12 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(5.2),
          location: "PHX Warehouse - Station P-14",
          source: "MasterFlow conversation",
          classificationConfidence: 94,
          routingReason: "Printer intent and workstation context matched IT Support routing rule.",
          details: {
            printer: "PHX-PRN-22",
            workstation: "P-14"
          },
          history: [
            { at: new Date(now - 2.2 * 60 * 60 * 1000).toISOString(), text: "Ticket created and routed to IT Support." },
            { at: new Date(now - 12 * 60 * 1000).toISOString(), text: "Agent requested confirmation of the printer label." }
          ]
        },
        {
          id: "t-1814",
          number: "ME-2026-1814",
          title: "Sales order report access",
          description: "Access is needed to the sales order backlog report.",
          category: "Software access",
          priority: "P3 - Normal",
          queue: "Business Systems",
          requester: "Alexandra Tafoya",
          department: "Packaging Operations",
          assignee: "Priya Shah",
          status: "In progress",
          createdAt: new Date(now - 26 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 20 * 60 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(14),
          location: "Remote",
          source: "Email",
          classificationConfidence: 91,
          routingReason: "Access request and report name matched Business Systems queue.",
          details: {},
          history: [
            { at: new Date(now - 26 * 60 * 60 * 1000).toISOString(), text: "Ticket created from company email." },
            { at: new Date(now - 20 * 60 * 60 * 1000).toISOString(), text: "Manager approval requested." }
          ]
        },
        {
          id: "t-1760",
          number: "ME-2026-1760",
          title: "Laptop performance",
          description: "Laptop was slow when opening ERP and Outlook.",
          category: "Device / Performance",
          priority: "P3 - Normal",
          queue: "IT Support",
          requester: "Alexandra Tafoya",
          department: "Packaging Operations",
          assignee: "Jordan Kim",
          status: "Resolved",
          createdAt: new Date(now - 5 * 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 4 * 24 * 60 * 60 * 1000).toISOString(),
          slaDueAt: new Date(now - 4.5 * 24 * 60 * 60 * 1000).toISOString(),
          location: "PHX Office",
          source: "MasterFlow conversation",
          classificationConfidence: 89,
          routingReason: "Device performance terms matched IT Support routing rule.",
          details: {},
          history: [
            { at: new Date(now - 5 * 24 * 60 * 60 * 1000).toISOString(), text: "Ticket created." },
            { at: new Date(now - 4 * 24 * 60 * 60 * 1000).toISOString(), text: "Resolved after startup cleanup and operating system updates." }
          ]
        },
        {
          id: "t-p1-1849",
          number: "ME-2026-1849",
          title: "Outbound manifesting unavailable",
          description: "Outbound stations cannot manifest orders in the PHX warehouse.",
          category: "Warehouse operations outage",
          priority: "P1 - Critical",
          queue: "Warehouse Systems / On-call",
          requester: "Morgan Lee",
          assignee: "Unassigned",
          status: "New",
          createdAt: new Date(now - 18 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 18 * 60 * 1000).toISOString(),
          slaDueAt: isoMinutesFromNow(12),
          location: "PHX Warehouse - Outbound",
          source: "Shipping is stopped fast lane",
          classificationConfidence: 100,
          routingReason: "Direct P1 fast-lane submission; no AI classification gate.",
          details: {
            process: "Manifesting",
            affectedUsers: "12",
            started: "18 minutes ago"
          },
          history: [
            { at: new Date(now - 18 * 60 * 1000).toISOString(), text: "P1 created. On-call and operations leadership notified." }
          ]
        },
        {
          id: "t-triage-1838",
          number: "ME-2026-1838",
          title: "Cannot finish daily work",
          description: "The requester reported that a daily task cannot be completed but did not identify the system.",
          category: "Needs classification",
          priority: "P3 - Normal",
          queue: "Enterprise Triage",
          requester: "Taylor Jones",
          department: "Receiving",
          assignee: "Megan Delia",
          status: "Triage",
          createdAt: new Date(now - 3.5 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 2.9 * 60 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(1.4),
          location: "Unknown",
          source: "MasterFlow conversation",
          classificationConfidence: 42,
          routingReason: "Classification confidence was below the safe-routing threshold.",
          details: {
            requestTemplateId: "general-triage",
            originalText: "I can't finish my daily work and I'm honestly not sure who I'm supposed to ask about this.",
            employeeProfile: {
              name: "Taylor Jones", department: "Receiving", team: "Inbound Dock B",
              site: "Phoenix DC", workLocation: "Dock B", manager: "R. Alvarez",
              email: "taylor.jones@masterelectronics.com", phone: "(602) 555-0148"
            },
            clarifications: [
              { question: "What are you trying to get done?", answer: "Finish my daily receiving tasks." },
              { question: "Which system or device is involved?", answer: "Not sure — a screen I use every day." }
            ]
          },
          triage: {
            reason: "Classification confidence (42%) was below the 70% safe-routing threshold.",
            reasonType: "low-confidence",
            enteredAt: new Date(now - 3.5 * 60 * 60 * 1000).toISOString(),
            owner: "Megan Delia",
            candidates: [
              { category: "Report an issue to Help Desk", queue: "IT Help Desk", templateId: "printer-connectivity", confidence: 42 },
              { category: "Systems Intake", queue: "Business Enablement - Systems Intake", templateId: "systems-intake", confidence: 31 }
            ],
            missingInfo: ["Which system or device is affected", "Exact location or workstation"]
          },
          history: [
            { at: new Date(now - 3.5 * 60 * 60 * 1000).toISOString(), text: "Low-confidence request sent to Enterprise Triage (confidence 42%)." }
          ]
        },
        {
          id: "t-triage-1839",
          number: "ME-2026-1839",
          title: "Need access set up for a new process",
          description: "Requester asked for help getting set up for a new process but the owning team is ambiguous between IT and Facilities.",
          category: "Needs classification",
          priority: "P3 - Normal",
          queue: "Enterprise Triage",
          requester: "Jordan Blake",
          department: "Packaging Operations",
          assignee: "Unassigned",
          status: "Triage",
          createdAt: new Date(now - 1.6 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 1.4 * 60 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(2.4),
          location: "Phoenix DC — Line 2",
          source: "MasterFlow conversation",
          classificationConfidence: 55,
          routingReason: "Two destinations matched with similar confidence; the correct owner is ambiguous.",
          details: {
            requestTemplateId: "general-triage",
            originalText: "I'm starting on the new labeling process and need to get set up — not sure if that's IT or Facilities.",
            employeeProfile: {
              name: "Jordan Blake", department: "Packaging Operations", team: "Line 2",
              site: "Phoenix DC", workLocation: "Line 2", manager: "M. Okafor",
              email: "jordan.blake@masterelectronics.com", phone: "(602) 555-0151"
            },
            clarifications: [
              { question: "What are you trying to get done?", answer: "Get set up for the new labeling process." }
            ]
          },
          triage: {
            reason: "Two destinations matched with similar confidence (IT Help Desk 55% vs Facilities 49%) — the correct owner is ambiguous.",
            reasonType: "conflict",
            enteredAt: new Date(now - 1.6 * 60 * 60 * 1000).toISOString(),
            owner: "Unassigned",
            candidates: [
              { category: "Report an issue to Help Desk", queue: "IT Help Desk", templateId: "printer-connectivity", confidence: 55 },
              { category: "Equipment Out of Service", queue: "Facilities", templateId: "equipment-out-of-service", confidence: 49 }
            ],
            missingInfo: ["Whether the setup is a system/login need or a physical equipment need"]
          },
          history: [
            { at: new Date(now - 1.6 * 60 * 60 * 1000).toISOString(), text: "Conflicting routes detected; sent to Enterprise Triage for a routing decision." }
          ]
        },
        {
          id: "t-approval-1846",
          number: "ME-2026-1846",
          title: "Replacement scanner purchase",
          description: "Replacement handheld scanner requested for receiving.",
          category: "Service request / Purchase",
          priority: "P3 - Normal",
          queue: "Warehouse Technology",
          requester: "Jamie Chen",
          assignee: "Alexandra Tafoya",
          status: "Approval required",
          createdAt: new Date(now - 80 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 45 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(4.5),
          location: "PHX Warehouse - Receiving",
          source: "MasterFlow form",
          classificationConfidence: 97,
          routingReason: "Purchase request exceeded the configured approval threshold.",
          details: { estimatedCost: "$1,285" },
          history: [
            { at: new Date(now - 80 * 60 * 1000).toISOString(), text: "Request created." },
            { at: new Date(now - 45 * 60 * 1000).toISOString(), text: "Director approval requested." }
          ]
        },
        {
          id: "t-team-1851",
          number: "ME-2026-1851",
          title: "Printer offline at Pack Station 14",
          description: "Zebra label printer at Pack Station 14 shows offline; work slowed for the packing team.",
          category: "IT Information / Report an issue to Help Desk",
          priority: "P3 - Normal",
          queue: "IT Help Desk",
          requester: "Marcus Reed",
          department: "Packaging Operations",
          assignee: "Jordan Kim",
          status: "In progress",
          createdAt: new Date(now - 55 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 20 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(3.4),
          location: "PHX Warehouse - Pack Station 14",
          source: "MasterFlow conversation",
          classificationConfidence: 96,
          routingReason: "Printer symptom and station context matched IT Help Desk.",
          details: { printerName: "PHX-PRN-14", symptom: "Offline or disconnected" },
          history: [
            { at: new Date(now - 55 * 60 * 1000).toISOString(), text: "Ticket created and routed to IT Help Desk." },
            { at: new Date(now - 20 * 60 * 1000).toISOString(), text: "Help Desk confirmed the printer and began remote checks." }
          ]
        },
        {
          id: "t-team-1852",
          number: "ME-2026-1852",
          title: "Label printer jam at Packaging Line 2",
          description: "Label printer on Packaging Line 2 keeps jamming during high-volume runs.",
          category: "IT Information / Report an issue to Help Desk",
          priority: "P3 - Normal",
          queue: "IT Help Desk",
          requester: "Priya Nair",
          department: "Packaging Operations",
          assignee: "Unassigned",
          status: "Waiting on requester",
          createdAt: new Date(now - 6 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 90 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(2),
          location: "PHX Warehouse - Packaging Line 2",
          source: "MasterFlow conversation",
          classificationConfidence: 92,
          routingReason: "Recurring jam symptom matched IT Help Desk.",
          details: { symptom: "Paper jam or feed problem" },
          history: [
            { at: new Date(now - 6 * 60 * 60 * 1000).toISOString(), text: "Ticket created and routed to IT Help Desk." },
            { at: new Date(now - 90 * 60 * 1000).toISOString(), text: "Help Desk asked for the label stock part number." }
          ]
        },
        {
          id: "t-team-1853",
          number: "ME-2026-1853",
          title: "Replacement scanner for packing",
          description: "Handheld scanner for the packing team is failing intermittently; requesting a replacement.",
          category: "IT Information / New IT Hardware Request",
          priority: "P3 - Normal",
          queue: "IT Information",
          requester: "Devon Brooks",
          department: "Packaging Operations",
          assignee: "Unassigned",
          status: "New",
          createdAt: new Date(now - 3 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(now - 3 * 60 * 60 * 1000).toISOString(),
          slaDueAt: isoHoursFromNow(20),
          location: "PHX Warehouse - Packaging",
          source: "MasterFlow form",
          classificationConfidence: 95,
          routingReason: "Hardware acquisition intent matched New IT Hardware Request.",
          details: { hardwareType: "Handheld scanner" },
          history: [
            { at: new Date(now - 3 * 60 * 60 * 1000).toISOString(), text: "Request created and routed to IT Information." }
          ]
        }
      ],
      knowledgeArticles: [
        {
          id: "kb-printer",
          title: "Connect to a network printer",
          category: "Hardware",
          summary: "Find the printer label or IP address and add it through Windows Printers & scanners.",
          steps: [
            "Open Settings and select Bluetooth & devices.",
            "Select Printers & scanners, then Add device.",
            "Use the printer name or IP address printed on the device label.",
            "Create a ticket if the printer is not found or access is denied."
          ],
          tags: ["printer", "network", "Windows"],
          helpful: 94
        },
        {
          id: "kb-laptop",
          title: "First steps for a slow laptop",
          category: "Device performance",
          summary: "Use a safe checklist before opening a performance ticket.",
          steps: [
            "Save work and restart the laptop once.",
            "Open Task Manager and note unusually high CPU or memory usage.",
            "Do not force-close company security or management software.",
            "Create a ticket and include whether one app or the entire device is affected."
          ],
          tags: ["laptop", "slow", "performance"],
          helpful: 88
        },
        {
          id: "kb-email",
          title: "Continue a ticket by email",
          category: "Using MasterFlow",
          summary: "Reply to the MasterFlow notification without creating a second request.",
          steps: [
            "Open the ticket confirmation email.",
            "Reply above the marked line with your update or attachment.",
            "The reply is added to the same ticket conversation.",
            "Use My tickets to see the complete timeline."
          ],
          tags: ["email", "ticket", "update"],
          helpful: 91
        },
        {
          id: "kb-p1",
          title: "When to use Shipping is stopped",
          category: "Warehouse operations",
          summary: "Use the P1 fast lane only when shipping or a critical warehouse process is blocked.",
          steps: [
            "Choose Shipping is stopped from the home page or side menu.",
            "Provide the warehouse, blocked process, start time, affected users, and symptom.",
            "The system immediately alerts on-call support and operations leadership.",
            "Do not wait for chatbot classification during an active outage."
          ],
          tags: ["P1", "shipping", "warehouse"],
          helpful: 97
        },
        {
          id: "kb-access",
          title: "Request access to a system or report",
          category: "Access",
          summary: "Include the system, role, business reason, and approving manager.",
          steps: [
            "Name the system or report.",
            "Describe what work the access enables.",
            "Identify your manager or required approver.",
            "Submit the request; MasterFlow will route the approval."
          ],
          tags: ["access", "report", "approval"],
          helpful: 86
        },
        {
          id: "kb-barcode",
          title: "Barcode scanner is not reading",
          category: "Warehouse technology",
          summary: "Check power, connection, and the active input field before creating a ticket.",
          steps: [
            "Confirm the scanner is powered and connected.",
            "Click in the expected barcode field and scan again.",
            "Try a known-good barcode label.",
            "Use Shipping is stopped only if the issue blocks the active warehouse process."
          ],
          tags: ["scanner", "barcode", "warehouse"],
          helpful: 90
        }
      ],
      settings: {
        ticketClassificationThreshold: 70,
        manualReviewConfidence: 70,
        autoActionConfidence: 90,
        directorApprovalThreshold: 1000,
        annualServiceNowCost: 300000,
        p1ResponseMinutes: 15,
        normalResponseHours: 4,
        normalResolutionHours: 24
      },
      routingRules: [
        { id: "rr-printer", name: "Printer and peripheral requests", condition: "Category contains Printer", route: "IT Support", active: true },
        { id: "rr-warehouse", name: "Warehouse application incidents", condition: "Location is warehouse and process is blocked", route: "Warehouse Systems / On-call", active: true },
        { id: "rr-triage", name: "Low-confidence classification", condition: "AI confidence below 70%", route: "Enterprise Triage", active: true }
      ],
      approvalRules: [
        { id: "ar-purchase", name: "Purchase request over $1,000", approver: "Director", active: true }
      ],
      assignmentRules: [
        { id: "asg-printer-conn", name: "Printer specialist assignment", queue: "IT Help Desk", templateId: "printer-connectivity", category: "Report an issue to Help Desk", primaryAssignee: "Jordan Kim", backupAssignee: "Taylor Morgan", fallback: "unassigned", active: true, priority: 1, notes: "Printer connectivity issues go to the printer specialist.", createdBy: "Queue Manager", updatedAt: new Date(now - 24 * 60 * 60 * 1000).toISOString(), appliedCount: 4 },
        { id: "asg-printer-ink", name: "Printer supply assignment", queue: "IT Information", templateId: "printer-ink", category: "Printer Ink Request", primaryAssignee: "Taylor Morgan", backupAssignee: "Jordan Kim", fallback: "unassigned", active: true, priority: 1, notes: "Ink and toner requests go to Taylor.", createdBy: "Queue Manager", updatedAt: new Date(now - 24 * 60 * 60 * 1000).toISOString(), appliedCount: 2 }
      ],
      teamAvailability: {
        "Jordan Kim": true,
        "Taylor Morgan": true,
        "Priya Shah": true,
        "Casey Rivera": true
      },
      flowImprovements: [],
      classificationFeedback: [
        { id: "cf-seed-1", phrase: "printer stopped working at my station", originalCategory: "Needs classification", originalConfidence: 48, correctedCategory: "IT Information / Report an issue to Help Desk", correctedQueue: "IT Help Desk", reason: "Printer issue confirmed from requester clarification.", by: "Megan Delia", at: new Date(now - 26 * 60 * 60 * 1000).toISOString(), sentToFlowStudio: false },
        { id: "cf-seed-2", phrase: "printer not printing labels", originalCategory: "Needs classification", originalConfidence: 52, correctedCategory: "IT Information / Report an issue to Help Desk", correctedQueue: "IT Help Desk", reason: "Original description was too ambiguous; confirmed printer connectivity.", by: "Megan Delia", at: new Date(now - 20 * 60 * 60 * 1000).toISOString(), sentToFlowStudio: false }
      ],
      employees: [
        { id: "emp-megan", name: "Megan Delia", employeeId: "ME-1001", email: "megan.delia@masterelectronics.com", department: "Business Enablement", team: "Platform Governance", site: "Phoenix HQ", manager: "COO", role: "Enterprise Administrator", queues: [], managerQueues: [], ownedCategories: [], flowStudio: false, assignmentRules: false, reporting: true, admin: true, active: true },
        { id: "emp-jkim", name: "Jordan Kim", employeeId: "ME-4471", email: "jordan.kim@masterelectronics.com", department: "IT", team: "IT Help Desk", site: "Phoenix DC", manager: "Megan Delia", role: "Service Team Member", queues: ["IT Help Desk"], managerQueues: [], ownedCategories: ["Report an issue to Help Desk"], flowStudio: false, assignmentRules: false, reporting: false, admin: false, active: true },
        { id: "emp-tmorgan", name: "Taylor Morgan", employeeId: "ME-4472", email: "taylor.morgan@masterelectronics.com", department: "IT", team: "IT Help Desk", site: "Phoenix DC", manager: "Megan Delia", role: "Queue Manager", queues: ["IT Help Desk", "IT Information"], managerQueues: ["IT Help Desk", "IT Information"], ownedCategories: ["Report an issue to Help Desk", "Printer Ink Request", "New IT Hardware Request"], flowStudio: true, assignmentRules: true, reporting: true, admin: false, active: true },
        { id: "emp-pshah", name: "Priya Shah", employeeId: "ME-4488", email: "priya.shah@masterelectronics.com", department: "IT", team: "Systems Intake", site: "Phoenix DC", manager: "Megan Delia", role: "Service Team Member", queues: ["Business Enablement - Systems Intake"], managerQueues: [], ownedCategories: ["Systems Intake"], flowStudio: false, assignmentRules: false, reporting: false, admin: false, active: true },
        { id: "emp-crivera", name: "Casey Rivera", employeeId: "ME-4490", email: "casey.rivera@masterelectronics.com", department: "IT", team: "IT Information", site: "Phoenix DC", manager: "Taylor Morgan", role: "Service Team Member", queues: ["IT Information"], managerQueues: [], ownedCategories: ["New IT Hardware Request"], flowStudio: false, assignmentRules: false, reporting: false, admin: false, active: true },
        { id: "emp-mreed", name: "Marcus Reed", employeeId: "ME-4501", email: "marcus.reed@masterelectronics.com", department: "Facilities", team: "Facilities Ops", site: "Phoenix DC", manager: "D. Chen", role: "Service T